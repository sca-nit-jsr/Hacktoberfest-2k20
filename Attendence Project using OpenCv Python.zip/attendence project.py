########################################################################################################
##      Attendence Project Using OpenCv Python
##      Note: This project can be improved further to a great extent

#    Developer:  Sovan Mondal (India)
#    Email: sovanmondal4@gmail.com

#########################################################################################################

import cv2
import numpy as np
import face_recognition
import os
from datetime import  datetime

path='ImagesAttendance'     # NOTE: please make a proper dataset with proper human faces before running this Project.
# creating list for importing images        ##  Otherwise you'll get "list out of Bound" Error..for no face images in your dataset.
images=[]
classNames=[]
mylist=os.listdir(path) # storimg the name of the images
# print(mylist) # Show the names in the data set available to you.

for cl in mylist:
    curImage=cv2.imread(f'{path}/{cl}')
    images.append(curImage) #takinf images from specified directory and storing it into another list automaticly
    classNames.append(os.path.splitext(cl)[0])  # storing only the name of the image files except the extensions
# print(classNames) # here we check that only name of the images is stored not the extension itself.

# creating fucting to find All the encodings automaticly
def findEncoding(images):
    encodeList=[]
    for img in images:
        img=cv2.cvtColor(img,cv2.COLOR_BGR2RGB)
        encode=face_recognition.face_encodings(img)[0]     #note: if you get  list out of index error then there is an images in your
        encodeList.append(encode)
    return encodeList

#________Function for taking attendence excluding duplicate value

def markAttendence(name):
    with open('Attendence.csv','r+')as f:           # Note: You can use Append(a+) mode to take the multiple attendence of the same person in every second.
        myDataList=f.readlines()
        nameList=[]
        for line in myDataList:
            entry=line.split(',')   # in each line we searate name and tie with respect to comma
            nameList.append(entry[0]) # append only the name
        if name not in nameList:
            now=datetime.now()
            dstring=now.strftime('%H:%M:%S')
            f.writelines(f'\n{name},{dstring}')

# calling functing for known faces
encodeListKnown=findEncoding(images)
print('Encoding Complete')

#....taking live feed from webcam

cap=cv2.VideoCapture(0)

while True:
    success,img=cap.read()
    imSmall=cv2.resize(img,(0,0),None,0.25,0.25)    #resizing for fast operation by 025 means 1/4 of original image
    imSmall=cv2.cvtColor(imSmall,cv2.COLOR_BGR2RGB)

    facesCurFrame=face_recognition.face_locations(imSmall)  #finding out requied faces amng many faces
    encodesCurFrame=face_recognition.face_encodings(imSmall,facesCurFrame)  # to encode we are sending th e resized small images and the location of the face detected

    #finding maches..

    for encodeFace,faceLoc in zip(encodesCurFrame,facesCurFrame): #taking each pair of face and its encodings
        matches= face_recognition.compare_faces(encodeListKnown,encodeFace) #retuen a list as [false,true,false,false and so on]
      #  print(matches)
        faceDis=face_recognition.face_distance(encodeListKnown,encodeFace)
        print(faceDis)      # Note: You can ignore this, to see the encoding match value, lower-one is accurate.
        matchIndex=np.argmin(faceDis) #as we can see the  output value of first image is less most..hence based on this we can fing out first image and so on
        #print("matchindex",matchIndex)  #resunt the index of the list for thw the true value exists in matches list

        #....
        if matches[matchIndex]:
            name=classNames[matchIndex].upper()
           # print(name)
            y1,x2,y2,x1=faceLoc
            y1, x2, y2, x1=y1*4,x2*4,y2*4,x1*4
            cv2.rectangle(img,(x1,y1),(x2,y2),(0,255,0),3)
            cv2.rectangle(img,(x1,y2-35),(x2,y2),(0,255,0),cv2.FILLED)
            cv2.putText(img,name,(x1+6,y2-6),cv2.FONT_HERSHEY_COMPLEX,1,(255,255,255),2)
            markAttendence(name)

            #showing images original


    cv2.imshow('Webcam',img)
    cv2.waitKey(5)





